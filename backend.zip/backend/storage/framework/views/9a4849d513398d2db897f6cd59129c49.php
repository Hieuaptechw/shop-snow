<?php $__env->startSection('content'); ?>
<div class="list-product">
    <h3>List Product</h3>
    <table class="product-list-table">
        <tr class="product-list-table-header">
            <td>ID</td>
            <td>Name</td>
            <td>Price</td>
            <td>Image</td>
            <td>Quantity</td>
            <td>Option</td>
        </tr>
        <?php $__currentLoopData = $productlist; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <td><?php echo e($product->product_id); ?></td>
            <td><?php echo e($product->name); ?></td>
            <td>$<?php echo e($product->price); ?></td>
            <td><img src="#" alt="Product Image" style="width:70px;"></td>
            <td>15</td>
            <td>
                <button type="submit" class="btn btn-primary btn-sm">Edit</button>
                <button type="submit" class="btn btn-danger btn-sm">Delete</button>
            </td>
        </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </table>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Windows\Documents\GitHub\shop-snow\backend\resources\views/admin/listproduct.blade.php ENDPATH**/ ?>