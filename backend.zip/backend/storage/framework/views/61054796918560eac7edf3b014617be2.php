<?php $__env->startSection('content'); ?>
<div class="categories">
    <?php if(session('success')): ?>
        <div class="alert alert-success">
            <?php echo e(session('success')); ?>

        </div>
    <?php endif; ?>
    <?php if(session('fail')): ?>
        <div class="alert alert-fail">
            <?php echo e(session('fail')); ?>

        </div>
    <?php endif; ?>
    <div class="categorie-from">
        <div class="row">
            <h3><?php echo e(isset($category) ? 'Edit Category' : 'Add Category'); ?></h3>
            <form method="POST" action="<?php echo e(isset($category) ? url('/admin/categories/update/'. $category->category_id) : url('/admin/categories/add')); ?>"  onsubmit="return confirmUpdate()">
                <?php echo csrf_field(); ?>
                <?php if(isset($category)): ?>
                    <?php echo method_field('PUT'); ?>
                <?php endif; ?>
                <div class="form-floating mb-3">
                    <input type="text" class="form-control" name="name" id="floatingInput" placeholder="Category Name" value="<?php echo e(isset($category) ? $category->name : ''); ?>" required>
                    <label for="floatingInput">Category:</label>
                </div>
                <button type="submit" class="btn btn-primary"><?php echo e(isset($category) ? 'Update' : 'Add'); ?></button>
            </form>
        </div>
        
    </div>
    <div class="categorie-list">
        <h3>List Category</h3>
        <table class="categorie-list-table">
            <tr class="categorie-list-table-header">
                <td>ID</td>
                <td>Name</td>
                <td>Option</td>
            </tr>
            <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $categorys): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($categorys->category_id); ?></td>
                    <td><?php echo e($categorys->name); ?></td>
                    <td>
                        <form action="<?php echo e(url('/admin/categories/delete/' . $categorys->category_id)); ?>" method="POST"
                            style="display:inline;"  onsubmit="return confirmDelete();">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('DELETE'); ?>
                            <button type="submit" class="btn btn-danger btn-sm">Delete</button>
                        </form>
                        <a href="<?php echo e(url('/admin/categories/edit/' . $categorys->category_id)); ?>" class="btn btn-primary btn-sm">Edit</a>
                    </td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </table>

        <!-- Phân trang -->
        <?php echo e($categories->links()); ?>

    </div>
</div>
<script>
    function confirmDelete() {
        return confirm('Bạn có chắc chắn muốn xoá');
}
function confirmUpdate() {
    var isEdit = <?php echo e(isset($category) ? 'true' : 'false'); ?>;
    if (isEdit) {
        return confirm('Bạn có chắc chắn muốn cập nhật?');
    };
    return true;
    }

</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Windows\Documents\GitHub\shop-snow\backend\resources\views/admin/categories.blade.php ENDPATH**/ ?>