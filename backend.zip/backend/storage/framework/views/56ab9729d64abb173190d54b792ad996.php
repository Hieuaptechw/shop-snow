<?php $__env->startSection('content'); ?>
    <div class="brand">
        <?php if(session('success')): ?>
            <div class="alert alert-success">
                <?php echo e(session('success')); ?>

            </div>
        <?php endif; ?>
        <?php if(session('fail')): ?>
            <div class="alert alert-fail">
                <?php echo e(session('fail')); ?>

            </div>
        <?php endif; ?>
        <div class="brand-from">
            <div class="row">
                <h3><?php echo e(isset($brand) ? 'Edit Brand' : 'Add Brand'); ?></h3>
                <form method="POST" action="<?php echo e(isset($brand) ? url('/admin/brand/update/' . $brand->brand_id) : url('/admin/brand/add')); ?>" onsubmit="return confirmUpdate()">
                    <?php echo csrf_field(); ?>
                    <?php if(isset($brand)): ?>
                        <?php echo method_field('PUT'); ?>
                    <?php endif; ?>
                    <div class="form-floating mb-3">
                        <input type="text" class="form-control" name="name" id="floatingInput" placeholder="Brand Name" value="<?php echo e(isset($brand) ? $brand->name : ''); ?>" required>
                        <label for="floatingInput">Brand:</label>
                    </div>
                    <button type="submit" class="btn btn-primary"><?php echo e(isset($brand) ? 'Update' : 'Add'); ?></button>
                </form>
                
            </div>

        </div>
        <div class="brand-list">
            <h3>List Brand</h3>
            <table class="brand-list-table">
                <tr class="brand-list-table-header">
                    <td>ID</td>
                    <td>Name</td>
                    <td>Option</td>
                </tr>
                <?php $__currentLoopData = $brands; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $branditem): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($branditem->brand_id); ?></td>
                        <td><?php echo e($branditem->name); ?></td>
                        <td>
                            <form action="<?php echo e(url('/admin/brand/delete/' . $branditem->brand_id)); ?>" method="POST"
                                style="display:inline;" onsubmit="return confirmDelete();">
                                <?php echo csrf_field(); ?>
                                <?php echo method_field('DELETE'); ?>
                                <button type="submit" class="btn btn-danger btn-sm">Delete</button>
                            </form>
                            <a href="<?php echo e(url('/admin/brand/edit/' . $branditem->brand_id)); ?>"
                                class="btn btn-primary btn-sm">Edit</a>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </table>
            <?php echo e($brands->links()); ?>


        </div>
    </div>
    <script>
        function confirmDelete() {
            return confirm('Bạn có chắc chắn muốn xoá?');
        }

        function confirmUpdate() {
            var isEdit = <?php echo e(isset($brand) ? 'true' : 'false'); ?>;
            if (isEdit) {
                return confirm('Bạn có chắc chắn muốn cập nhật?');
            };
            return true;
        }
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Windows\Documents\GitHub\shop-snow\backend\resources\views/admin/brand.blade.php ENDPATH**/ ?>